# Ti.Storekit.ProductRequest

## Description

A _Ti.Storekit_ module object which represents an asynchronous request to the in-app
purchase store for a product.

## Functions

### Ti.Storekit.ProductRequest.cancel()

Cancels an active request to the store.